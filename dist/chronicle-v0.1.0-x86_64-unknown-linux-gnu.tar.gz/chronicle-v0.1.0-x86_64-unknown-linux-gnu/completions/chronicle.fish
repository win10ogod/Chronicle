# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_chronicle_global_optspecs
	string join \n root= commit= h/help V/version
end

function __fish_chronicle_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_chronicle_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_chronicle_using_subcommand
	set -l cmd (__fish_chronicle_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c chronicle -n "__fish_chronicle_needs_command" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_needs_command" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_needs_command" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_needs_command" -s V -l version -d 'Print version'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "init" -d 'Initialize `.chronicle` directory structure in the project'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "remember" -d 'Store a new memory block (and commit it to Git)'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "recall" -d 'Recall memory blocks using the MAMA matching algorithm'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "consolidate" -d 'Move eligible short-term memories into long-term storage'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "forget" -d 'Apply forgetting: move low-strength memories to archive or delete'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "log" -d 'Show memory change history (wraps `git log`)'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "branch" -d 'Git branch helpers for sandboxed reasoning'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "completions" -d 'Print shell completion script'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "wal" -d 'Internal: process WAL tasks'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "status" -d 'Print project status summary'
complete -c chronicle -n "__fish_chronicle_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chronicle -n "__fish_chronicle_using_subcommand init" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand init" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand init" -l git-init -d 'Create the Git repository if missing (`git init`)'
complete -c chronicle -n "__fish_chronicle_using_subcommand init" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -s m -l msg -d 'Memory message/body (Markdown supported)' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -l id -d 'Optional explicit id / filename stem (e.g. `Rust` creates `Rust.md`)' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -l layer -d 'Store in short-term or long-term layer' -r -f -a "short\t''
long\t''
archive\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -s t -l tags -d 'Extra tags (repeatable)' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -l no-commit -d 'Skip Git commit (still writes the file)'
complete -c chronicle -n "__fish_chronicle_using_subcommand remember" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -s q -l query -d 'Search query' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -s k -l top-k -l top -d 'Number of results to return' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l include-archive -d 'Include archive results'
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l no-touch -d 'Do not update access metadata (hit_count/last_access)'
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l json -d 'Output JSON for agent consumption'
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l no-assoc -d 'Skip associative expansion via `[[links]]`'
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -l no-commit -d 'Skip Git commit for access metadata updates'
complete -c chronicle -n "__fish_chronicle_using_subcommand recall" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -l min-hits -d 'Consolidate if hit_count >= this value' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -l min-age-hours -d 'Consolidate if age (hours) >= this value (0 disables)' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -l dry-run -d 'Preview actions without writing'
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -l no-commit -d 'Skip Git commit'
complete -c chronicle -n "__fish_chronicle_using_subcommand consolidate" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -l id -d 'Delete a specific memory by id' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -l threshold -d 'Archive long-term memories whose ACT-R heat is below this threshold (0..1 recommended)' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -l dry-run -d 'Preview actions without writing'
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -l no-commit -d 'Skip Git commit'
complete -c chronicle -n "__fish_chronicle_using_subcommand forget" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand log" -l limit -d 'Maximum number of commits to show' -r
complete -c chronicle -n "__fish_chronicle_using_subcommand log" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand log" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand log" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "create" -d 'Create and checkout a new branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "checkout" -d 'Checkout an existing branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "merge" -d 'Merge a branch into the current branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "list" -d 'List local branches'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "current" -d 'Print current branch name'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "delete" -d 'Delete a local branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and not __fish_seen_subcommand_from create checkout merge list current delete help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from create" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from create" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from create" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from checkout" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from checkout" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from checkout" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from merge" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from merge" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from merge" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from list" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from list" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from current" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from current" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from current" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from delete" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from delete" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from delete" -l force
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "create" -d 'Create and checkout a new branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "checkout" -d 'Checkout an existing branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "merge" -d 'Merge a branch into the current branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "list" -d 'List local branches'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "current" -d 'Print current branch name'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "delete" -d 'Delete a local branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand branch; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chronicle -n "__fish_chronicle_using_subcommand completions" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand completions" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand completions" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and not __fish_seen_subcommand_from run help" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and not __fish_seen_subcommand_from run help" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and not __fish_seen_subcommand_from run help" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and not __fish_seen_subcommand_from run help" -f -a "run"
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and not __fish_seen_subcommand_from run help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and __fish_seen_subcommand_from run" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and __fish_seen_subcommand_from run" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and __fish_seen_subcommand_from run" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and __fish_seen_subcommand_from help" -f -a "run"
complete -c chronicle -n "__fish_chronicle_using_subcommand wal; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chronicle -n "__fish_chronicle_using_subcommand status" -l root -d 'Project root (defaults to auto-detect from current directory)' -r -F
complete -c chronicle -n "__fish_chronicle_using_subcommand status" -l commit -d 'Git commit mode after write/touch operations' -r -f -a "sync\t''
async\t''
off\t''"
complete -c chronicle -n "__fish_chronicle_using_subcommand status" -s h -l help -d 'Print help'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "init" -d 'Initialize `.chronicle` directory structure in the project'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "remember" -d 'Store a new memory block (and commit it to Git)'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "recall" -d 'Recall memory blocks using the MAMA matching algorithm'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "consolidate" -d 'Move eligible short-term memories into long-term storage'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "forget" -d 'Apply forgetting: move low-strength memories to archive or delete'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "log" -d 'Show memory change history (wraps `git log`)'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "branch" -d 'Git branch helpers for sandboxed reasoning'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "completions" -d 'Print shell completion script'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "wal" -d 'Internal: process WAL tasks'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "status" -d 'Print project status summary'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and not __fish_seen_subcommand_from init remember recall consolidate forget log branch completions wal status help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from branch" -f -a "create" -d 'Create and checkout a new branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from branch" -f -a "checkout" -d 'Checkout an existing branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from branch" -f -a "merge" -d 'Merge a branch into the current branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from branch" -f -a "list" -d 'List local branches'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from branch" -f -a "current" -d 'Print current branch name'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from branch" -f -a "delete" -d 'Delete a local branch'
complete -c chronicle -n "__fish_chronicle_using_subcommand help; and __fish_seen_subcommand_from wal" -f -a "run"
